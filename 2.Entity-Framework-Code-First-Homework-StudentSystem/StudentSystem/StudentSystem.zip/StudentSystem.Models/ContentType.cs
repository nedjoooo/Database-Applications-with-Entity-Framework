﻿namespace StudentSystem.Models
{
    public enum ContentType
    {
        ApplicationPdf,
        ApplicationZip
    }
}
