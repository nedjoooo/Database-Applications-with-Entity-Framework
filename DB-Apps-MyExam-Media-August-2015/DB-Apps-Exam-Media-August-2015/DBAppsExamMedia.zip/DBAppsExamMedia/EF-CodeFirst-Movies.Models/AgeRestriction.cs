﻿namespace EF_CodeFirst_Movies.Models
{
    public enum AgeRestriction
    {
        Child,
        Teen,
        Adult
    }
}
